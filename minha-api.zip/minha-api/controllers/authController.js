const User = require('../models/User.js');
const jwt = require('jsonwebtoken');

// Função para gerar os tokens
const generateTokens = (userId) => {
    const accessToken = jwt.sign({ userId }, process.env.ACCESS_TOKEN_SECRET, {
        expiresIn: process.env.ACCESS_TOKEN_EXPIRATION,
    });
    const refreshToken = jwt.sign({ userId }, process.env.REFRESH_TOKEN_SECRET, {
        expiresIn: process.env.REFRESH_TOKEN_EXPIRATION,
    });
    return { accessToken, refreshToken };
};

// Lógica para registrar um usuário
exports.register = async (req, res) => {
    try {
        const { name, email, password } = req.body;

        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'Este e-mail já está em uso.' });
        }

        const user = new User({ name, email, password });
        await user.save(); // Aqui o "hook" do model vai criptografar a senha

        res.status(201).json({ message: 'Usuário criado com sucesso!' });
    } catch (error) {
        res.status(500).json({ message: 'Erro interno do servidor.' });
    }
};

// Lógica para fazer login
exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;
        // Pedimos para o banco incluir a senha na busca com .select('+password')
        const user = await User.findOne({ email }).select('+password');

        if (!user || !(await user.comparePassword(password))) {
            return res.status(401).json({ message: 'E-mail ou senha inválidos.' });
        }

        const { accessToken, refreshToken } = generateTokens(user._id);

        const userResponse = user.toObject();
        delete userResponse.password; // Remove a senha antes de enviar a resposta

        res.json({ accessToken, refreshToken, user: userResponse });
    } catch (error) {
        res.status(500).json({ message: 'Erro interno do servidor.' });
    }
};

// GET /me -> Retorna os dados do usuário logado
exports.getMe = async (req, res) => {
    try {
        // O ID do usuário vem do nosso authMiddleware (req.user.userId)
        const user = await User.findById(req.user.userId);
        if (!user) {
            return res.status(404).json({ message: 'Usuário não encontrado.' });
        }
        res.json(user);
    } catch (error) {
        res.status(500).json({ message: 'Erro interno do servidor.' });
    }
};

// POST /auth/refresh -> Gera um novo access token
exports.refresh = (req, res) => {
    const { refreshToken } = req.body;
    if (!refreshToken) {
        return res.status(401).json({ message: 'Refresh token é obrigatório.' });
    }

    try {
        // Verifica se o refresh token é válido
        const decoded = jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET);

        // Se for válido, gera um novo conjunto de tokens
        const { accessToken, refreshToken: newRefreshToken } = generateTokens(decoded.userId);

        res.json({ accessToken, refreshToken: newRefreshToken });
    } catch (error) {
        // Se o refresh token for inválido ou estiver expirado
        return res.status(403).json({ message: 'Refresh token inválido ou expirado.' });
    }
};