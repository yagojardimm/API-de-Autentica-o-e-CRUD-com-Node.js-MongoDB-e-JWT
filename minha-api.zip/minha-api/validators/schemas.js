const { z } = require('zod');

const registerSchema = z.object({
    body: z.object({
        name: z.string().min(3, 'O nome precisa ter no mínimo 3 caracteres.'),
        email: z.string().email('Formato de e-mail inválido.'),
        password: z.string().min(6, 'A senha precisa ter no mínimo 6 caracteres.'),
    }),
});

const loginSchema = z.object({
    body: z.object({
        email: z.string().email('Formato de e-mail inválido.'),
        password: z.string().min(1, 'A senha é obrigatória.'),
    }),
});

module.exports = {
    registerSchema,
    loginSchema,
};

// ... (schemas de register e login) ...

const createTodoSchema = z.object({
    body: z.object({
        title: z.string().min(1, 'O título da tarefa é obrigatório.'),
    }),
});

const updateTodoSchema = z.object({
    body: z.object({
        title: z.string().min(1).optional(),
        done: z.boolean().optional(),
    }),
    params: z.object({
        id: z.string().regex(/^[0-9a-fA-F]{24}$/, 'ID da tarefa inválido.'), // Valida se parece um ObjectId do MongoDB
    }),
});

// Não se esqueça de exportá-los!
module.exports = {
    registerSchema,
    loginSchema,
    createTodoSchema,
    updateTodoSchema,
};
