const validate = (schema) => (req, res, next) => {
    try {
        schema.parse({
            body: req.body,
            query: req.query,
            params: req.params,
        });
        next(); // Se a validação passar, continua para o controller
    } catch (error) {
        // Se falhar, retorna um erro claro
        return res.status(400).json({
            message: 'Erro de validação de dados.',
            errors: error.errors,
        });
    }
};

module.exports = validate;