const express = require('express');
const router = express.Router();
const todoController = require('../controllers/todoController');
const authMiddleware = require('../middlewares/authMiddleware');
const validate = require('../middlewares/validate'); // <-- IMPORTAR
const { createTodoSchema, updateTodoSchema } = require('../validators/schemas'); // <-- IMPORTAR

router.use(authMiddleware);

router.post('/', validate(createTodoSchema), todoController.createTodo); // <-- APLICAR
router.get('/', todoController.getAllTodos);
router.get('/:id', todoController.getTodoById);
router.put('/:id', validate(updateTodoSchema), todoController.updateTodoById); // <-- APLICAR
router.delete('/:id', todoController.deleteTodoById);

module.exports = router;
