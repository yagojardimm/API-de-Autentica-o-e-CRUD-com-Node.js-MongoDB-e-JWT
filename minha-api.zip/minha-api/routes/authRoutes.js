const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const validate = require('../middlewares/validate'); // Vamos criar este arquivo em breve
const { registerSchema, loginSchema } = require('../validators/schemas');

// Rota para Registro
router.post('/register', validate(registerSchema), authController.register);

// Rota para Login
router.post('/login', validate(loginSchema), authController.login);

const authMiddleware = require('../middlewares/authMiddleware'); // Importe o middleware

// ... (rotas de register e login) ...

// Rota para buscar dados do usuário logado (protegida)
router.get('/me', authMiddleware, authController.getMe);
// ... (outras rotas) ...

// Rota para renovar os tokens
router.post('/refresh', authController.refresh);

router.get('/me', authMiddleware, authController.getMe);

module.exports = router;